ALHUDU TV — راهنمای راه‌اندازی

وضعیت: فایل‌های سایت آماده‌اند، اما تا وقتی منتشر نشوند و قوانین Firestore تنظیم نشوند، آنلاین کار نمی‌کنند.

۱. در Firebase Console > Authentication > Users روی کاربر مدیر بزنید و User UID او را کپی کنید (رمز را نفرستید).
۲. در فایل firestore.rules متن REPLACE_WITH_ADMIN_UID را با UID واقعی عوض کنید.
۳. در Firebase Console > Firestore Database > Rules محتوای فایل firestore.rules را قرار دهید و Publish بزنید.
۴. فایل‌های پوشه را در ریشه یک وب‌سایت HTTPS قرار دهید (مثلاً GitHub Pages). فایل‌های admin.js، tv.js، config.js و style.css باید کنار HTMLها باشند.
۵. در Firebase Console > Authentication > Settings > Authorized domains دامنه میزبان سایت (مثلاً username.github.io) را اضافه کنید.
۶. از آدرس admin.html وارد شوید، با ایمیل و رمز Firebase Auth لاگین کنید و فایل‌ها را آپلود کنید.
۷. آدرس tv.html را در مرورگر تلویزیون باز کنید. تغییرات پلی‌لیست به‌صورت زنده نمایش داده می‌شوند.

نکات:
- Cloudinary preset برابر alhudu_tv و cloud name برابر bsllvscn در config.js قرار داده شده‌اند.
- آپلود Unsigned برای راه‌اندازی ساده است، اما هرکس preset و cloud name را بداند ممکن است مستقیماً در Cloudinary آپلود کند. برای استفاده بلندمدت و ایمن‌تر، آپلود امضاشده سمت سرور لازم است.
- حذف از پلی‌لیست فایل اصلی را از Cloudinary حذف نمی‌کند؛ پاکسازی فایل‌های بلااستفاده از Cloudinary Media Library انجام می‌شود.
- ویدیوها در TV بی‌صدا پخش می‌شوند تا autoplay روی مرورگرها بهتر کار کند.
- در بعضی تلویزیون‌ها پخش خودکار یا حالت تمام‌صفحه محدودیت مرورگر دارد.
- Firebase و Cloudinary سقف استفاده رایگان دارند؛ از حجم و ترافیک مصرفی مراقبت کنید.
